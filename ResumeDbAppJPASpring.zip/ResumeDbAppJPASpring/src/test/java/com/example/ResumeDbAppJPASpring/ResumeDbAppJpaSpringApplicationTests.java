package com.example.ResumeDbAppJPASpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeDbAppJpaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
